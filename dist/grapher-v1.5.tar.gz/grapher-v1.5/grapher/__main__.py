from grapher import Grapher

print("Here are some sample plots for you.")
g = Grapher([])
g.examples()
